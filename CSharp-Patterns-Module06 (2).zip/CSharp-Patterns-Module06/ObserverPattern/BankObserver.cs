using System;

public class BankObserver : IObserver
{
    public void Update(decimal usdRate)
    {
        Console.WriteLine($"🏦 Банк жаңа курс алды: 1 USD = {usdRate} KZT");
    }
}
