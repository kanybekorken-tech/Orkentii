using System;

public class BankCardPayment : IPaymentStrategy
{
    public void Pay(double amount)
    {
        Console.WriteLine($"💳 Банктік карта арқылы {amount} теңге төленді.");
    }
}
