public interface IObserver
{
    void Update(decimal usdRate);
}
