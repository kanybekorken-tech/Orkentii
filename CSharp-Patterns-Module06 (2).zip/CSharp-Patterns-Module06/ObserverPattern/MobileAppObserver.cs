using System;

public class MobileAppObserver : IObserver
{
    public void Update(decimal usdRate)
    {
        Console.WriteLine($"📱 Мобильді қосымша хабарлама: доллар бағамы {usdRate}");
    }
}
