using System;

class Program
{
    static void Main(string[] args)
    {
        CurrencyExchange exchange = new CurrencyExchange();

        var bank = new BankObserver();
        var mobile = new MobileAppObserver();
        var news = new NewsPortalObserver();

        exchange.Attach(bank);
        exchange.Attach(mobile);
        exchange.Attach(news);

        Console.Write("Доллардың жаңа бағамын енгізіңіз: ");
        decimal rate = decimal.Parse(Console.ReadLine());
        exchange.UsdRate = rate;

        Console.WriteLine("\n✅ Барлық бақылаушыларға хабар жіберілді!");
    }
}
