using System;

public class PayPalPayment : IPaymentStrategy
{
    public void Pay(double amount)
    {
        Console.WriteLine($"💻 PayPal арқылы {amount} теңге төленді.");
    }
}
