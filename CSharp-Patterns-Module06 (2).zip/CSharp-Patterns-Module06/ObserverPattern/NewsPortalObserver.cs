using System;

public class NewsPortalObserver : IObserver
{
    public void Update(decimal usdRate)
    {
        Console.WriteLine($"📰 Жаңалықтар порталы: доллардың жаңа бағамы — {usdRate}!");
    }
}
