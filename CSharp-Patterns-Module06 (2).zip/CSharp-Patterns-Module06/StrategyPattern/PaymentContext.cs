public class PaymentContext
{
    private IPaymentStrategy _paymentStrategy;

    public void SetStrategy(IPaymentStrategy strategy)
    {
        _paymentStrategy = strategy;
    }

    public void ExecutePayment(double amount)
    {
        if (_paymentStrategy == null)
        {
            Console.WriteLine("⚠️ Төлем стратегиясы таңдалмаған!");
            return;
        }

        _paymentStrategy.Pay(amount);
    }
}
