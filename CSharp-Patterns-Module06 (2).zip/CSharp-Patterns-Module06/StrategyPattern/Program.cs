using System;

class Program
{
    static void Main(string[] args)
    {
        PaymentContext context = new PaymentContext();

        Console.WriteLine("Төлем әдісін таңдаңыз: 1 - Карта, 2 - PayPal, 3 - Крипто");
        int choice = int.Parse(Console.ReadLine());

        switch (choice)
        {
            case 1:
                context.SetStrategy(new BankCardPayment());
                break;
            case 2:
                context.SetStrategy(new PayPalPayment());
                break;
            case 3:
                context.SetStrategy(new CryptoPayment());
                break;
            default:
                Console.WriteLine("Қате таңдау!");
                return;
        }

        Console.Write("Төлем сомасын енгізіңіз: ");
        double amount = double.Parse(Console.ReadLine());

        context.ExecutePayment(amount);

        Console.WriteLine("✅ Төлем сәтті орындалды!");
    }
}
