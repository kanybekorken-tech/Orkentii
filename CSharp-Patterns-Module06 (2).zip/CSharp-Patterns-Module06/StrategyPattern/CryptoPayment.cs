using System;

public class CryptoPayment : IPaymentStrategy
{
    public void Pay(double amount)
    {
        Console.WriteLine($"🪙 Криптовалюта арқылы {amount} теңге төленді.");
    }
}
